import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import java.awt.GridLayout;
import java.awt.CardLayout;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.AbstractListModel;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Desktop;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.beans.PropertyChangeEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class BlenderBulkRender extends JFrame {

	private JPanel contentPane;
	private JTextField BlenderLocation;
	private JTextField blend;
	private DefaultListModel<Object> dlm = new DefaultListModel<>();
	private ArrayList<String>BlendFilesList=new ArrayList<String>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BlenderBulkRender frame = new BlenderBulkRender();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BlenderBulkRender() {
		setResizable(false);
		setTitle("Blender Bulk Render");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 636, 347);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList<Object> BlendFiles = new JList<Object>();
		BlendFiles.setToolTipText("");
		BlendFiles.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				if(arg0.getKeyCode() == 127)
				{
					DefaultListModel<Object> model = (DefaultListModel<Object>) BlendFiles.getModel();
					int selectedIndex = BlendFiles.getSelectedIndex();
					if (selectedIndex != -1) {
					    model.remove(selectedIndex);
					}
				}
			}
		});
		
		JButton btnRender = new JButton("Render");
		btnRender.setEnabled(false);

		btnRender.setForeground(Color.BLACK);
		btnRender.setBounds(191, 274, 251, 37);
		contentPane.add(btnRender);
		
		BlenderLocation = new JTextField();
		BlenderLocation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(BlenderLocation.getText()!= "" && BlendFiles.getModel().getSize()>0)
				{
					btnRender.setEnabled(true);
				}
				else
				{
					btnRender.setEnabled(false);
				}
			}
		});		
		BlenderLocation.setBounds(10, 36, 610, 28);
		contentPane.add(BlenderLocation);
		BlenderLocation.setColumns(10);	
		
		JLabel lblBlenderLocation = new JLabel("Blender Location :");
		lblBlenderLocation.setBounds(10, 11, 160, 14);
		contentPane.add(lblBlenderLocation);
		
		JLabel lblblendFileLocation = new JLabel(".Blend File Location (Full Path) : ");
		lblblendFileLocation.setBounds(10, 75, 293, 14);
		contentPane.add(lblblendFileLocation);	
		

		BlendFiles.setForeground(Color.BLACK);
		
		blend = new JTextField();
		blend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				addIteamToList(BlenderLocation,BlendFiles,btnRender,blend.getText());
			}
		});
		blend.setColumns(10);
		blend.setBounds(10, 100, 512, 28);
		contentPane.add(blend);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addIteamToList(BlenderLocation,BlendFiles,btnRender,blend.getText());
			}
		});
		btnAdd.setBounds(532, 100, 88, 28);
		contentPane.add(btnAdd);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setToolTipText("");
		scrollPane.setBounds(10, 139, 610, 124);
		contentPane.add(scrollPane);
		
		BlendFiles.setModel(new AbstractListModel() {
			ArrayList<String> values = BlendFilesList;
			public int getSize() {
				return values.size();
			}
			public Object getElementAt(int index) {
				return values.get(index);
			}
		});
		scrollPane.setViewportView(BlendFiles);
		
		btnRender.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{		
				 MakeSaveFile();
				 MakeBatFile();
			}
			
			void MakeBatFile()
			{	
				File filename = new File("BlenderBulkRender.bat");
				   if (filename.exists()) {
					   filename.delete();     
				    }
				
				PrintWriter writer = null;
				try
				{
					writer = new PrintWriter(filename);
				}
				catch(FileNotFoundException c)
				{
					c.printStackTrace();
				}
				
				try{ 
					Runtime.getRuntime().exec("attrib +h \""+filename.getAbsolutePath().toString()+"\""); 
					}catch(Exception e1){} 

					
				
				writer.println("@echo off");
				
				writer.println(BlenderLocation.getText().charAt(0)+":");
				writer.println("cd "+BlenderLocation.getText());
				for(int i = 0;i<BlendFiles.getModel().getSize();i++)
				{
					if(i != 0)
						writer.print(" && " + "blender -b "+"\"" + BlendFiles.getModel().getElementAt(i) + "\""+" -x 1 -a");
					else
						writer.print("blender -b "+"\"" + BlendFiles.getModel().getElementAt(i) + "\""+" -x 1 -a"); 									
				}
				
				writer.println("");
				
				writer.println("pause");
				
				writer.println("attrib -h \""+filename.getAbsolutePath().toString()+"\"");
				
				writer.println("del /f/q "+"%~0"+" | exit");
				
				writer.close();
				
				try {
					Desktop.getDesktop().open(filename);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				filename.deleteOnExit();
			}
			
			void MakeSaveFile()
			{
								
				File filename = new File("BlenderBulkRenderSave.txt");	
				
				if(filename.exists())
				{
					filename.delete();
				}
				
				PrintWriter writer = null;
				try
				{
					writer = new PrintWriter(filename);
				}
				catch(FileNotFoundException c)
				{
					c.printStackTrace();
				}
				
				try{ 
					Runtime.getRuntime().exec("attrib +h \""+filename.getAbsolutePath().toString()+"\""); 
					}catch(Exception e1){} 
					
				writer.println(BlenderLocation.getText());
				writer.println(BlendFiles.getModel().getSize());
				for(int i = 0;i<BlendFiles.getModel().getSize();i++)
				{
					writer.println(BlendFiles.getModel().getElementAt(i)); 									
				}
				
				writer.println("");				
								
				writer.close();
								
			}
			
			
		});
		
		try {
			FindSaveFile(BlenderLocation,BlendFiles,btnRender);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
	}

	private void FindSaveFile(JTextField BlenderLocationTextField,JList<Object> BlendFiles,JButton btnRender) throws IOException {
		
			BufferedReader reader = null;
			String[] BlendFileArray;		
			String Savedtext ="";		
			
			try{
				FileReader file = new FileReader("BlenderBulkRenderSave.txt");
				reader = new BufferedReader(file);
			}
			catch(FileNotFoundException c)
			{
				c.printStackTrace();
				return;
			}
						
			String line = reader.readLine();
			
			while(line!=null)
			{
				Savedtext += line+" ..!. ";
				line = reader.readLine();
			}
			
			reader.close();
			
			System.out.println(Savedtext);
			BlendFileArray = Savedtext.split(" ..!. ");
			for(int i = 0;BlendFileArray.length > i; i++)
			{
				System.out.println(" "+i+" : "+BlendFileArray[i]);
			}
			
			BlenderLocationTextField.setText(BlendFileArray[0]);
			
			for(int i = 0;Integer.parseInt(BlendFileArray[1]) > i; i++)
			{
				String text = BlendFileArray[2+i];
				
				addIteamToList(BlenderLocation,BlendFiles,btnRender,text);
			}
			
		
		}
	
	private void addIteamToList(JTextField BlenderLocationTextField,JList<Object> BlendFiles,JButton btnRender,String AddedIteam)
	{		
		if(AddedIteam.charAt(0) == '"')
		{
			AddedIteam = AddedIteam.replaceAll("\"", "");
		}

		
		BlendFilesList.add(AddedIteam);
		dlm.addElement(AddedIteam);
		BlendFiles.setModel(dlm);
		blend.setText("");
		if(BlenderLocation.getText()!= "" && BlendFiles.getModel().getSize()>0)
		{
			btnRender.setEnabled(true);
		}
		else
		{
			btnRender.setEnabled(false);
		}
	}
	}


	

	
